package cargame_list;

import java.util.Random;

public class Car { // 자동차 배열 생성
    final int score = 0;
    final int random_range = 10;
    final int condition_range = 4;
    int count;
    int car;
    int moveable;
    int[] carData;

    public void score(int carInput, int moveInput) {
        count = moveInput;
        car = carInput;
    }
    
    public int carScore() {
        Random random = new Random();

        for (int i = 0; i < car; i++){
        moveable = 0; // 기본값
        for (int j = 0; j < count; j++) {
            if (random.nextInt(random_range) >= condition_range) {
                this.moveable++;
            }
        }
        carData[i] = moveable;
    }
        return this.moveable;
    }
}

// for (int i = 0; i < car; i++) {
//     score.carScore();
//     int carScore = score.moveable;
//     carData[i] = carScore;
//     System.out.print(carData[i] + "확인좀;");
// }