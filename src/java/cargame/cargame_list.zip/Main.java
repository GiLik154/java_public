package cargame_list;

public class Main {

	public static void main(String[] args) {
		Text input = new Text();
		input.scan();
		
		int car = input.reciveCar();
		int count = input.reciveCount();
		
		Score reslut = new Score();
		reslut.makeScore(car, count);
	}
}
