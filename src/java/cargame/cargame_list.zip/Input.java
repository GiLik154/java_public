package cargame_list;

import java.util.Scanner;

class Text {
    int car;
    int count;
    void scan() {
        Scanner input = new Scanner(System.in);
        
        System.out.println("자동차 대수는 몇 대 인가요?");
        this.car = input.nextInt();
        System.out.println(car + "대");

        System.out.println("시도할 횟수는 몇 회 인가요?");
        this.count = input.nextInt();
        System.out.println(count + "번");
        input.close();
    }
    int reciveCar() {
        return this.car;
    }
    int reciveCount() {
        return this.count;
    }
}