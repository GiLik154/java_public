package cargame_list;

public class Score {

    void makeScore(int cars, int count, int carData[]) {
        
        int car = cars;
        int moveCount = count;
        int[] carasd = new int carData[];
        
        // for (int i = 0; i < car; i++) {
        //     score.carScore();
        //     int carScore = score.moveable;
        //     carData[i] = carScore;
        //     System.out.print(carData[i] + "확인좀;");
        // }

        for (int i = 0; i < moveCount + 1; i++) { // 카운트 만큼 반복
            System.out.println(i + "회진행");
            for (int j = 0; j < car; j++) { // 차량의 대수 만큼 반복
                for (int k = 0; k < carData[j] + 1; k++) { // 차량의 점수만큼 반복
                    if (k < i + 1) {
                        System.out.print("-");
                    }
                }
                System.out.println("");
            }
        }
    }
}