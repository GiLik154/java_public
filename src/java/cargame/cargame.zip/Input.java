package cargame;

import java.util.Scanner;

// class text {
//     static int scan(){
//         Scanner input = new Scanner(System.in);
//         int abcd = input.nextInt();
//         // input.close();
//         return abcd;
//     }
//     public static int cars() {
//         System.out.println("자동차 대수는 몇 대 인가요?");
//         int car = scan();
//         System.out.println(car + "대");
//         return car;
//     }
//     public static int count() {
//         System.out.println("시도할 횟수는 몇 회 인가요?");
//         int count = scan();
//         System.out.println(count + "번");
//         return count;
//     }
// }

class Text {
    static void scan() {
        Scanner input = new Scanner(System.in);
        System.out.println("자동차 대수는 몇 대 인가요?");
        int car = input.nextInt();
        System.out.println(car + "대");
        System.out.println("시도할 횟수는 몇 회 인가요?");
        int count = input.nextInt();
        System.out.println(count + "번");
        input.close();

        Cars.car(car, count);
    }
}