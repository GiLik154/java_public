package cargame;

class Print {
    public static void main() {
        System.out.print("☆");
    }

    public static void line() {
        System.out.println("");
    }

    public static void move(int i) {
        System.out.println(i + 1 + "회진행");
    }
}