package cargame;

public class Main {

	public static void main(String[] args) {
		Text.scan();
	}
}
