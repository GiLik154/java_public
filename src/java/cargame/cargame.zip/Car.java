package cargame;

import java.util.Random;

// class Cars { // 자동차 배열 생성
//     public static void car() {
//         int car = text.cars();
//         int cars[] = new int[car];
//         int count = text.count();
//         Random random = new Random();

//         for (int i = 0; i < count; i++) { // 움직일 횟수
//             Print.move(i);
//             for (int e = 0; e < cars.length; e++) {
//                 for(int h = cars[e]; h < i+1; h++){
//                  Print.main();
//                 } // 차 번호
//                 if (random.nextInt(10) >= 4) {
//                     cars[e] = cars[e] + 1;
//                 }
//                 Print.line();
//             }
//         }
//     }
// }

class Cars { // 자동차 배열 생성
    public static void car(int carCount, int moveCount) {
        int cars[] = new int[carCount];
        int count = moveCount;
        Random random = new Random();

        for (int i = 0; i < count; i++) { // 움직일 횟수
            Print.move(i);
            for (int e = 0; e < cars.length; e++) {
                for (int h = cars[e]; h < i + 1; h++) {
                    Print.main();
                } // 차 번호
                if (random.nextInt(10) >= 4) {
                    cars[e] = cars[e] + 1;
                }
                Print.line();
            }
        }
    }
}