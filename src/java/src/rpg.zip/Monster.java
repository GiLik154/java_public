package rpg;

public class Monster {
	String name;
	int hp;
	int attack;

	void createMonster(String name, int hp, int attack) {
		this.name = name;
		this.hp = hp;
		this.attack = attack;
	}

	int hp() {
		return hp;
	}

	int attack() {
		return attack;
	}
}
