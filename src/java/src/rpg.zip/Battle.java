package rpg;

import java.util.Random;

public class Battle {
	Random random = new Random();
	String name;
	int userAtt;
	int userRandomAtt;
	static int userHp;
	int mobHp;
	int mobAtt;
	int mobRandomAtt;

	void battleChar(String name, int hp, int attack) {

		Character elf = new Character();
		elf.createCharacter(name, hp, attack);

		Monster orc = new Monster();
		orc.createMonster("orc", 100, 10);

		userHp = elf.hp();
		userAtt = elf.attack();
		mobHp = orc.hp();
		mobAtt = orc.attack();
		
		battle();
	}

	void battle() {
		while (true) {
			userHp = userHp - random.nextInt(mobAtt + 1);
			mobHp = mobHp - random.nextInt(userAtt + 1);
			System.out.println("유저체력 : " + userHp);
			System.out.println("몬스터체력 : " + mobHp);
			if (userHp <= 0 || mobHp <= 0) {
				break;
			}
		}

	}
	static int returnhp() {
		return userHp;
	}
}
