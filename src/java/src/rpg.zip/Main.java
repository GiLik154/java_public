package rpg;

import java.util.Random;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Random random = new Random();
		int heal = random.nextInt(5) + 1;
		String choice;
		Scanner input = new Scanner(System.in);

		CharInfo user = new CharInfo("elf", 200, 10);
		String name = user.userInfoName();
		int hp = user.userInfoHp();
		int attack = user.userInfoAttack() + 1;
		
		go: while (true) {
			System.out.println("전투, 회복, 종료");
			choice = input.next();
			switch (choice) {
			case "전투":
				Battle start = new Battle();
				start.battleChar(name, hp, attack);
				hp = start.returnhp();
				break;
			case "회복":
				hp = hp + heal;
				System.out.println("체력을"+heal + "만큼 회복하였습니다." + "현재 hp :" + hp);
				break;
			case "종료":
				break go;

			}
		}
	}
}