package site.util.utility;

public class ConstantsReply {
	public static final String B_REPLY_NUM = "b_reply_num";
	public static final String B_REPLY_ORIGIN = "b_reply_origin";
	public static final String B_REPLY_CONTENTS = "b_reply_contents";
	public static final String B_REPLY_TIME = "b_reply_time";
	public static final String B_REPLY_WRITER = "b_reply_writer";
}
