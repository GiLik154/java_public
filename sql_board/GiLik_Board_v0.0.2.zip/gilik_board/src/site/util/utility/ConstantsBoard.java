package site.util.utility;

public class ConstantsBoard {
	public static final String B_NUM = "b_num";
	public static final String B_TITLE = "b_title";
	public static final String B_WRITER = "b_writer";
	public static final String B_TIME = "b_time";
	public static final String B_HITS = "b_hits";
	public static final String B_CONTENTS = "b_contents";
	public static final String B_REPLY_EACH = "b_reply_each";
}
