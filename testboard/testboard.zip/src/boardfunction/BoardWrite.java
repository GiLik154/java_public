package boardfunction;

import java.io.*;

public class BoardWrite {
    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    public String title;
    public String content;
    public String writer;
    public int num = 0;

    void writeNum(int num){
        this.num = num;

    }

    public void write() {
        try {
            num++;
            bw.write(" 글 작성을 시작합니다" + "\n");
            bw.flush();

            writeTitle();
            writeContents();
            writeWriter();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void writeTitle() {
        try {
            bw.write(" 글 제목을 입력해주세요" + "\n");
            bw.flush();
            title = br.readLine();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void writeContents() {
        try {
            bw.write(" 글 내용을 입력해주세요" + "\n");
            bw.flush();
            content = br.readLine();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void writeWriter() {
        try {
            bw.write(" 글 작성자를 입력해주세요" + "\n");
            bw.flush();
            writer = br.readLine();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
