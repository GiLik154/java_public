package boardfunction;

import boardinfo.BoardInfo;

import java.io.*;
import java.util.List;

public class BoardCorrect {
    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    int inputNum = 0;
    String selectMenu = "";
    String correctString = "";

    public void inpoutNum() {
        try {
            bw.write("몇 번 글을 수정하시나요?");
            bw.flush();
            inputNum = Integer.parseInt(br.readLine());

        } catch (Exception e) {
            try{
                bw.write("잘못된 입력입니다." + "\n");
                bw.flush();

            }catch (IOException d){
                d.printStackTrace();
            }
        }
    }

    public void selectMenu() {
        try {
            bw.write(inputNum + "번 글을 수정합니다." + "\n" + "\n");
            bw.write("1.제목/2.내용/3.작성자/e.나가기" + "\n" + "\n");
            bw.flush();
            selectMenu = br.readLine();

        } catch (Exception e) {
            try{
                bw.write("잘못된 입력입니다." + "\n");
                bw.flush();

            }catch (IOException d){
                d.printStackTrace();
            }
        }
    }

    public void printCorrectBoard(List<BoardInfo> list) {
        try {
            boolean cheak = false;
            int num = 0;
            for (BoardInfo i : list) {
                num += 1;
                if (inputNum == i.num) {
                    cheak = true;
                    break;
                }



            }

            if (cheak) {
                while (true) {
                    switch (selectMenu) {
                        case "1":
                            try {
                                bw.write(inputNum + "번 글 제목을 수정합니다" + "\n");
                                bw.write("수정할 제목을 입력해주세요." + "\n");
                                bw.flush();
                                list.get(num -1).title = br.readLine();
                                bw.write("수정 완료되었습니다." + "\n");
                                bw.flush();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            return;

                        case "2":
                            try {
                                bw.write(inputNum + "번 글 내용을 수정합니다" + "\n");
                                bw.write("수정할 내용을 입력해주세요." + "\n");
                                bw.flush();
                                list.get(num -1).content = br.readLine();
                                bw.write("수정 완료되었습니다." + "\n");
                                bw.flush();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            return;

                        case "3":
                            try {
                                bw.write(inputNum + "번 글 작성자를 수정합니다" + "\n");
                                bw.write("수정할 작성자를 입력해주세요." + "\n");
                                bw.flush();
                                list.get(num -1).writer = br.readLine();
                                bw.write("수정 완료되었습니다." + "\n");
                                bw.flush();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            return;

                        case "e":
                            try {
                                bw.write("종료합니다." + "\n");
                                bw.flush();
                                return;
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            break;
                        default:
                            bw.write("잘못된 입력입니다." + "\n");
                            bw.flush();
                    }


                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


