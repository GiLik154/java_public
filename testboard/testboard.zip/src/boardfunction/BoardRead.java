package boardfunction;

import boardinfo.BoardInfo;

import java.io.*;
import java.util.List;

public class BoardRead {
    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    int inputNum = 0;

    public void inpoutNum() {
        try {
            bw.write("몇 번 글을 읽으시나요?");
            bw.flush();
            inputNum = Integer.parseInt(br.readLine());

        } catch (Exception e) {
            try{
                bw.write("잘못된 입력입니다." + "\n");
                bw.flush();

            }catch (IOException d){
                d.printStackTrace();
            }
        }
    }

    public void printReadBoard(List<BoardInfo> list) {
        try {
            boolean check = false;
            int num = 0;
            for (BoardInfo i : list) {
                num += 1;
                if (inputNum == i.num) {
                    check = true;
                    break;
                }
            }

            if (check) {
                BoardInfo boardInfo = list.get(num -1);
                boardInfo.hits++; // 조회수 + 1;
                bw.write("글 번호 : " + boardInfo.num);
                bw.write(" || 글 제목 : " + boardInfo.title);
                bw.write(" || 글 작성자 : " + boardInfo.writer + "\n");
                bw.write("글 내용 : " + boardInfo.content + "\n");
                bw.write("글 조회 : " + boardInfo.hits);
                bw.write(" || 글 작성일 : " + boardInfo.date + "\n");
                bw.write("=================================================================================================" + "\n");
                bw.flush();
            } else {
                bw.write("일치하는 글이 없습니다.");
                bw.flush();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
