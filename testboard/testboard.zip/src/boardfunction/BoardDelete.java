package boardfunction;

import boardinfo.BoardInfo;

import java.io.*;
import java.util.List;

public class BoardDelete {
    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    int inputNum = 0;


    public void inpoutNum() {
        try {
            bw.write("몇 번 글을 삭제하시나요?");
            bw.flush();
            inputNum = Integer.parseInt(br.readLine());

        } catch (Exception e) {
            try{
                bw.write("잘못된 입력입니다." + "\n");
                bw.flush();

            }catch (IOException d){
                d.printStackTrace();
            }
        }
    }

    public void deleteBoard(List<BoardInfo> list) {
        try {
            boolean check = false;
            int num = 0;
            for (BoardInfo i : list) {
                num += 1;
                if (inputNum == i.num) {
                    check = true;
                    break;
                }
            }

            if (check) {
                list.remove(num - 1);
                bw.write(num + "번 글이 삭제되었습니다." + "\n");
                bw.write("=================================================================================================" + "\n");
                bw.flush();
            } else {
                bw.write("일치하는 글이 없습니다.");
                bw.flush();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
