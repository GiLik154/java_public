package boardmain;

import boardfunction.*;
import boardinfo.BoardInfo;

import java.io.*;
import java.util.*;

public class Menu {
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
        BufferedReader br = new BufferedReader(new InputStreamReader((System.in)));
        BoardList boardList = new BoardList();
        BoardCorrect boardCorrect = new BoardCorrect();
        BoardDelete boardDelete = new BoardDelete();
        BoardRead boardRead = new BoardRead();
        BoardWrite boardWrite = new BoardWrite();
        List<BoardInfo> list = new ArrayList<>();

void selectmenu(){

        try {
            while (true) {
                BoardInfo boardInfo = new BoardInfo();
                bw.write("🐈‍[1.글 리스트/2.글읽기/3.글쓰기/4.글삭제/5.글수정/e.종료]🐈" + "\n");
                bw.flush();
                String select = br.readLine();
                switch (select) {
                    case "1": // 글 리스트
                        boardList.printList(list);
                        break;
                    case "2": // 글 읽기
                        boardList.printList(list);
                        boardRead.inpoutNum();
                        boardRead.printReadBoard(list);
                        break;
                    case "3": // 글 쓰기
                        boardWrite.write();
                        boardInfo.receive(boardWrite);
                        list.add(boardInfo);
                        break;
                    case "4": // 글 삭제
                        boardList.printList(list);
                        boardDelete.inpoutNum();
                        boardDelete.deleteBoard(list);
                        break;
                    case "5": //글 수정
                        boardList.printList(list);
                        boardCorrect.inpoutNum();
                        boardCorrect.selectMenu();
                        boardCorrect.printCorrectBoard(list);
                        break;
                    case "e": //종료
                        bw.write("종료합니다." + "\n");
                        bw.flush();
                        return;
                    default:
                        bw.write("입력을 확인해주세요.");
                        bw.flush();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }

    }
}
